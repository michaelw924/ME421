%% Take Home Case 1
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Setting up a sample graph based on a sine function
syms x
y = x^3-10*x;

% Differentiate the equation using the diff function, specifying first the
% function to be differentiated, then the variable within the function
y_prime = diff(y,x);

% Use the solve function to identify where the differentiated function is
% equal to zero, and specify the variable x. Also, the name-value pair
% 'MaxDegree' can be used to specify 
extrema = solve(y_prime == 0, x);


% Plotting graph
figure;
fplot(y);
hold on;
plot(extrema, subs(y,extrema),'*');

% Labeling graph and axes, and setting axes limits
title('Take Home Case #1');
xlabel('Time (s)');
ylabel('Amplitude');

% 