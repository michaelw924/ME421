%% Activity 2
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Setup initial variables
t = 0.4;
x = 2;

% Calculate output
v = (sin(2*pi*t)+x)^2+2*x+exp(t);

% Format output
v_char = num2str(v);
output_char = strcat("The value at 0.4 seconds is ",v_char);

% Display output
disp(output_char);