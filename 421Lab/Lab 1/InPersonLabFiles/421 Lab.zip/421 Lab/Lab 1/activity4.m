function [y] = activity4(x,t)
%ACTIVITY4 
%   Take inputs for x and t and put into designated function below and
%   output

y = 2*sin(2*t)-3*x;

end

