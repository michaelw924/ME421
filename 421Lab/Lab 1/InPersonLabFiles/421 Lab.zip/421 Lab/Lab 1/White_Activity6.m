%% Activity 6
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Setup initial variables
h = 0.1;
x = 0:h:10;

% Generate y
for i = 1:length(x)
    if i > 1
        y(i) = y(i-1)+h*x(i);
    else
        y(i) = 1+h*x(i);
    end
end