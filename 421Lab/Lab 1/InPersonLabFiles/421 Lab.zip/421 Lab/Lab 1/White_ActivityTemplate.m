%% Activity #
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;