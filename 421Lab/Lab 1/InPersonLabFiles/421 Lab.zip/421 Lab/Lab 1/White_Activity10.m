%% Activity 10
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Run simulation for Activity 10 and output results to 'simout'
simout = sim('White_Activity10_sim');

% Generate figure and plot/label results
figure;
hold on;
plot(simout.time,simout.amplitude);
title('Activity 10: Amplitude (mm) vs. Time (s)');
xlabel('Time (s)');
ylabel('Amplitude (mm)');