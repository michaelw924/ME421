%% Activity 3
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Create initial vectors
v1 = 2:2:8;
v2 = linspace(1,10,4);
v3 = [3 7 2].';

% Calculate A
A = v2.*v3;

% Data extractions from A
x = A(3,2);
v4 = A(2,:);
B = A(2:3,2:3);