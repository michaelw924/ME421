%% Activity 4
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Setup initial matrix
A = [4 2;0 9];

% Find max
A_max = max(A,[],'all');

% Reset A
A = [1 5 6 2 85 14 6 4 23];

% Find difference
A_diff = diff(A);

% Setup initial functions for function activity4
x = 2;
t = 9;

% Evaluate activity4 with inputs
y = activity4(x,t); %y = 2sin(2t)-3x