%% Activity 9
% 2/12/21
% Michael White
% Section 3 / Online
close all;
clear all;
clc;

% Define initial variables
m = 4;

% Simulate the model
simout = sim('White_Activity9_sim');

% Plot the results
figure;
hold on;
plot(simout.time,simout.amplitude);
title('Activity 9: Amplitude (mm) vs. Time (s)');
xlabel('Time (s)');
ylabel('Amplitude (mm)');

% Note: this lab is having us output the time from the "clock" in the
% simulink environment to graph, but this is unnecessary since "tout" is an output
% from sim inherently